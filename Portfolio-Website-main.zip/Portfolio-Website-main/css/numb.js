function addNumbers() {
    let x = 0;
    for (let i = 1; i <= 50; i++) {
      x += i;
    }
    return x;
  }
  
  // Calling the function and displaying the result
  console.log(addNumbers());
  